import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";

// ─── CONFIG ───────────────────────────────────────────────────────────────────
// Set these in your .env.local file:
// VITE_SUPABASE_URL=https://xxxx.supabase.co
// VITE_SUPABASE_ANON_KEY=eyJ...
const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const ADMIN_PASSWORD = import.meta.env.VITE_ADMIN_PASSWORD || "fsf-admin-2026";

// Stage 1 locks June 11 2026 at 14:55 UTC (just before first kickoff 3pm ET)
const STAGE1_LOCK = new Date("2026-06-11T14:55:00Z");
// Stage 2 locks ~July 1 before R32 begins
const STAGE2_LOCK = new Date("2026-07-01T11:00:00Z");

// ─── TOURNAMENT DATA ──────────────────────────────────────────────────────────
export const GROUPS = {
  A: ["Mexico", "South Africa", "South Korea", "Czechia"],
  B: ["Canada", "Bosnia & Herz.", "Qatar", "Switzerland"],
  C: ["Brazil", "Morocco", "Haiti", "Scotland"],
  D: ["United States", "Paraguay", "Australia", "Türkiye"],
  E: ["Germany", "Curaçao", "Ivory Coast", "Ecuador"],
  F: ["Netherlands", "Japan", "Sweden", "Tunisia"],
  G: ["Belgium", "Egypt", "Iran", "New Zealand"],
  H: ["Spain", "Cape Verde", "Saudi Arabia", "Uruguay"],
  I: ["France", "Senegal", "Iraq", "Norway"],
  J: ["Argentina", "Algeria", "Austria", "Jordan"],
  K: ["Portugal", "DR Congo", "Uzbekistan", "Colombia"],
  L: ["England", "Croatia", "Ghana", "Panama"],
};

// Every group has 6 matches (round-robin of 4 teams = 4!/(2!2!) = 6)
export const GROUP_MATCHES = Object.entries(GROUPS).flatMap(([g, t]) => [
  { id: `${g}M1`, group: g, home: t[0], away: t[1] },
  { id: `${g}M2`, group: g, home: t[2], away: t[3] },
  { id: `${g}M3`, group: g, home: t[0], away: t[2] },
  { id: `${g}M4`, group: g, home: t[1], away: t[3] },
  { id: `${g}M5`, group: g, home: t[0], away: t[3] },
  { id: `${g}M6`, group: g, home: t[1], away: t[2] },
]);

export const ALL_TEAMS = Object.values(GROUPS).flat();

export const KNOCKOUT_ROUNDS = [
  { id: "r32",   label: "Round of 32",  points: 2,  slots: 16 },
  { id: "r16",   label: "Round of 16",  points: 4,  slots: 8  },
  { id: "qf",    label: "Quarterfinals",points: 8,  slots: 4  },
  { id: "sf",    label: "Semifinals",   points: 12, slots: 2  },
  { id: "final", label: "Final",        points: 16, slots: 1  },
];

// ─── SCORING ──────────────────────────────────────────────────────────────────
export function calcStage1Score(userPicks = {}, officialResults = {}) {
  let pts = 0, correct = 0;

  // Match results: 1 pt each
  GROUP_MATCHES.forEach(({ id }) => {
    const pick = userPicks.matchResults?.[id];
    const result = officialResults.matchResults?.[id];
    if (pick && result && pick === result) { pts += 1; correct += 1; }
  });

  // Group finishers
  Object.keys(GROUPS).forEach(g => {
    const p1 = userPicks.groupFirst?.[g];
    const p2 = userPicks.groupSecond?.[g];
    const r1 = officialResults.groupFirst?.[g];
    const r2 = officialResults.groupSecond?.[g];
    if (!r1 || !r2) return;
    if (p1) {
      if (p1 === r1)      { pts += 3; correct += 1; }
      else if (p1 === r2) { pts += 1; }
    }
    if (p2) {
      if (p2 === r2)      { pts += 2; correct += 1; }
      else if (p2 === r1) { pts += 1; }
    }
  });

  // Best 8 third-place: 1 pt each
  const thirdPicks = userPicks.thirdPlace || [];
  const thirdResults = officialResults.thirdPlace || [];
  thirdPicks.forEach(t => {
    if (thirdResults.includes(t)) { pts += 1; correct += 1; }
  });

  return { pts, correct };
}

export function calcStage2Score(userPicks = {}, officialResults = {}) {
  let pts = 0, correct = 0;
  KNOCKOUT_ROUNDS.forEach(({ id, points }) => {
    const roundPicks = userPicks.knockout?.[id] || {};
    const roundResults = officialResults.knockout?.[id] || {};
    Object.entries(roundResults).forEach(([slot, winner]) => {
      if (winner && roundPicks[slot] === winner) {
        pts += points; correct += 1;
      }
    });
  });
  return { pts, correct };
}

// ─── CSS ──────────────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,400;0,600;0,700;1,400&family=Barlow:wght@400;500;600&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --navy:       #0B1F3A;
  --navy-card:  #1A3354;
  --navy-light: #243e5f;
  --gold:       #EFB824;
  --gold-dim:   #b8880f;
  --cream:      #F3F3EE;
  --white:      #FFFFFF;
  --success:    #1D9E75;
  --danger:     #D93030;
  --muted:      #7A8FA0;
  --border:     rgba(255,255,255,0.10);
  --ff-display: 'Barlow Condensed', sans-serif;
  --ff-body:    'Barlow', sans-serif;
}

body {
  font-family: var(--ff-body);
  background: var(--cream);
  color: var(--navy);
  min-height: 100vh;
}

/* ── HEADER ── */
.header {
  background: var(--navy);
  position: sticky; top: 0; z-index: 200;
  box-shadow: 0 2px 16px rgba(0,0,0,.35);
}
.header-inner {
  max-width: 1080px; margin: 0 auto;
  padding: 0 1.25rem;
  display: flex; align-items: center; justify-content: space-between;
  height: 58px;
}
.brand { display: flex; align-items: baseline; gap: 10px; cursor: pointer; }
.brand-name {
  font-family: var(--ff-display);
  font-size: 24px; font-weight: 700;
  color: var(--gold);
  text-transform: uppercase; letter-spacing: 1.5px;
}
.brand-tag { font-size: 11px; color: rgba(255,255,255,.38); font-style: italic; }
@media(max-width:540px){ .brand-tag { display:none; } }

.nav { display: flex; align-items: center; gap: 2px; }
.nav-btn {
  background: none; border: none;
  color: rgba(255,255,255,.6);
  font-family: var(--ff-body); font-size: 13px; font-weight: 500;
  padding: 6px 9px; border-radius: 6px;
  cursor: pointer; transition: all .15s; white-space: nowrap;
}
.nav-btn:hover { background: rgba(255,255,255,.07); color: #fff; }
.nav-btn.active { color: var(--gold); background: rgba(239,184,36,.12); }

/* ── PAGE ── */
.page { max-width: 1080px; margin: 0 auto; padding: 1.75rem 1.25rem 4rem; }

/* ── SECTION HEAD ── */
.sh { display: flex; align-items: baseline; gap: 10px; margin-bottom: 1.25rem; padding-bottom: .6rem; border-bottom: 2px solid var(--navy); }
.sh-title { font-family: var(--ff-display); font-size: 26px; font-weight: 700; color: var(--navy); text-transform: uppercase; letter-spacing: .5px; }
.sh-sub { font-size: 12px; color: var(--muted); }

/* ── CARDS ── */
.card { background: var(--white); border-radius: 10px; border: 1px solid rgba(0,0,0,.08); padding: 1.25rem; box-shadow: 0 1px 3px rgba(0,0,0,.05); }
.card-navy { background: var(--navy); border-radius: 10px; padding: 1.25rem; }

/* ── STATS ── */
.stat-row { display: grid; grid-template-columns: repeat(auto-fit,minmax(130px,1fr)); gap: 8px; margin-bottom: 1.25rem; }
.stat { background: var(--navy-card); border-radius: 8px; padding: .9rem 1rem; text-align: center; }
.stat-lbl { font-size: 10px; color: var(--gold); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 3px; }
.stat-val { font-family: var(--ff-display); font-size: 30px; font-weight: 700; color: #fff; line-height: 1; }

/* ── BTNS ── */
.btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 5px;
  padding: 9px 18px; border-radius: 7px;
  font-family: var(--ff-body); font-size: 14px; font-weight: 600;
  cursor: pointer; transition: all .15s; border: none;
}
.btn-gold  { background: var(--gold); color: var(--navy); }
.btn-gold:hover  { background: #f7c93a; }
.btn-ghost { background: transparent; border: 1.5px solid var(--gold); color: var(--gold); }
.btn-ghost:hover { background: rgba(239,184,36,.1); }
.btn-danger { background: var(--danger); color: #fff; }
.btn-danger:hover { background: #b82525; }
.btn-success { background: var(--success); color: #fff; }
.btn-success:hover { background: #178a64; }
.btn-sm { padding: 5px 12px; font-size: 12px; }
.btn:disabled { opacity: .4; cursor: not-allowed; }

/* ── FORMS ── */
.fg { margin-bottom: .9rem; }
.lbl { display: block; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: .05em; color: var(--navy); margin-bottom: 4px; }
.inp {
  width: 100%; padding: 9px 13px;
  border: 1.5px solid rgba(0,0,0,.15); border-radius: 7px;
  font-family: var(--ff-body); font-size: 14px; color: var(--navy);
  background: #fff; transition: border-color .15s;
}
.inp:focus { outline: none; border-color: var(--gold); }
.inp.dark {
  background: var(--navy-light); border-color: rgba(255,255,255,.15); color: #fff;
}
.inp.dark::placeholder { color: rgba(255,255,255,.3); }
.inp.dark:focus { border-color: var(--gold); }
select.inp { cursor: pointer; }

/* ── TABS ── */
.tabs { display: flex; gap: 3px; background: rgba(0,0,0,.06); border-radius: 8px; padding: 3px; margin-bottom: 1.25rem; }
.tab {
  flex: 1; padding: 7px 10px; border: none; background: none;
  border-radius: 6px; font-family: var(--ff-body); font-size: 12px; font-weight: 600;
  cursor: pointer; color: var(--muted); transition: all .15s;
  text-transform: uppercase; letter-spacing: .04em;
}
.tab.active { background: var(--navy); color: var(--gold); }

/* ── ALERTS ── */
.alert { padding: 10px 14px; border-radius: 7px; font-size: 13px; font-weight: 500; margin-bottom: 1rem; }
.alert-ok   { background: rgba(29,158,117,.12); color: #0e6b4f; border: 1px solid rgba(29,158,117,.3); }
.alert-err  { background: rgba(217,48,48,.08);  color: #922020; border: 1px solid rgba(217,48,48,.22); }
.alert-info { background: rgba(239,184,36,.10); color: #7a5500; border: 1px solid rgba(239,184,36,.3); }

/* ── LOCK BANNER ── */
.lock-banner {
  background: rgba(239,184,36,.1); border: 1px solid rgba(239,184,36,.4);
  border-radius: 7px; padding: 10px 14px; margin-bottom: 1.25rem;
  font-size: 13px; color: #7a5500; font-weight: 500;
}

/* ── GROUP BLOCK ── */
.grp-block { background: #fff; border-radius: 10px; border: 1px solid rgba(0,0,0,.08); margin-bottom: 1.25rem; overflow: hidden; }
.grp-hd { background: var(--navy); padding: 9px 1.25rem; display: flex; justify-content: space-between; align-items: center; }
.grp-lbl { font-family: var(--ff-display); font-size: 18px; font-weight: 700; color: var(--gold); text-transform: uppercase; letter-spacing: 1px; }
.grp-teams { font-size: 11px; color: rgba(255,255,255,.5); }
.grp-body { padding: 1rem 1.25rem; }

/* ── MATCH ROW ── */
.match-row { display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; gap: 6px; padding: 7px 0; border-bottom: 1px solid rgba(0,0,0,.05); }
.match-row:last-child { border-bottom: none; }
.pick-btn {
  padding: 7px 10px; border-radius: 6px;
  border: 1.5px solid rgba(0,0,0,.11); background: #fff;
  font-family: var(--ff-body); font-size: 12px; font-weight: 500;
  cursor: pointer; transition: all .15s; text-align: center; color: var(--navy);
}
.pick-btn:hover:not(:disabled) { border-color: var(--gold); background: #fffaec; }
.pick-btn.sel { background: var(--navy); color: var(--gold); border-color: var(--navy); }
.draw-btn {
  padding: 7px 8px; border-radius: 6px;
  border: 1.5px solid rgba(0,0,0,.11); background: #fff;
  font-size: 10px; font-weight: 700; cursor: pointer;
  color: var(--muted); transition: all .15s; letter-spacing: .05em;
  white-space: nowrap;
}
.draw-btn:hover:not(:disabled) { border-color: var(--gold); }
.draw-btn.sel { background: var(--navy); color: var(--gold); border-color: var(--navy); }

/* ── FINISH PICKS ── */
.finish-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid rgba(0,0,0,.07); }
@media(max-width:420px){ .finish-grid { grid-template-columns: 1fr; } }
.finish-lbl { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; margin-bottom: 5px; }
.gold-lbl { color: var(--gold-dim); }
.silver-lbl { color: #5577aa; }

/* ── THIRD PLACE ── */
.third-grid { display: grid; grid-template-columns: repeat(auto-fill,minmax(120px,1fr)); gap: 6px; margin-top: .75rem; }
.third-btn {
  padding: 7px 9px; border-radius: 6px;
  border: 1.5px solid rgba(0,0,0,.11); background: #fff;
  font-size: 12px; font-weight: 500; cursor: pointer;
  transition: all .15s; text-align: center; color: var(--navy);
}
.third-btn:hover:not(:disabled) { border-color: var(--gold); }
.third-btn.sel { background: var(--navy); color: var(--gold); border-color: var(--navy); }
.third-btn:disabled { opacity: .35; cursor: not-allowed; }

/* ── KO SLOT ── */
.ko-slot { background: #fff; border: 1.5px solid rgba(0,0,0,.09); border-radius: 8px; padding: 10px; margin-bottom: 7px; }
.ko-slot-lbl { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: .06em; margin-bottom: 5px; }
.ko-teams { display: flex; gap: 6px; }

/* ── LEADERBOARD ── */
.lb-tbl { width: 100%; border-collapse: collapse; }
.lb-tbl th { text-align: left; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .07em; color: var(--gold); padding: 9px 11px; border-bottom: 1px solid rgba(255,255,255,.1); }
.lb-tbl td { padding: 11px; border-bottom: 1px solid rgba(255,255,255,.06); color: #fff; font-size: 14px; }
.lb-tbl tr:last-child td { border-bottom: none; }
.lb-tbl tr:hover td { background: rgba(255,255,255,.025); }
.rank-pill { display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 50%; font-weight: 700; font-size: 12px; }
.rk1 { background: var(--gold); color: var(--navy); }
.rk2 { background: #b0bec8; color: var(--navy); }
.rk3 { background: #c07850; color: #fff; }
.rkn { background: rgba(255,255,255,.1); color: #fff; }

/* ── AUTH ── */
.auth-bg { min-height: calc(100vh - 58px); display: flex; align-items: center; justify-content: center; background: var(--navy); padding: 2rem; }
.auth-box { background: var(--navy-card); border-radius: 14px; padding: 2.5rem; width: 100%; max-width: 400px; border: 1px solid rgba(255,255,255,.08); }
.auth-title { font-family: var(--ff-display); font-size: 34px; font-weight: 700; color: var(--gold); text-transform: uppercase; letter-spacing: 1px; }
.auth-sub { font-size: 12px; color: rgba(255,255,255,.4); font-style: italic; margin-bottom: 1.75rem; }

/* ── GUIDE ── */
.guide-h { font-family: var(--ff-display); font-size: 20px; font-weight: 700; color: var(--navy); text-transform: uppercase; display: inline-block; border-bottom: 2px solid var(--gold); padding-bottom: 3px; margin-bottom: .6rem; }
.guide-p { font-size: 14px; line-height: 1.7; color: #334455; margin-bottom: .6rem; }
.sc-tbl { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: .4rem; }
.sc-tbl th { text-align: left; padding: 7px 11px; background: var(--navy); color: var(--gold); font-size: 11px; text-transform: uppercase; }
.sc-tbl td { padding: 8px 11px; border-bottom: 1px solid rgba(0,0,0,.06); }
.sc-tbl tr:last-child td { border-bottom: none; }
.pts { display: inline-block; background: var(--navy); color: var(--gold); padding: 1px 7px; border-radius: 4px; font-weight: 700; font-size: 12px; }

/* ── SAVE BAR ── */
.save-bar { display: flex; justify-content: flex-end; align-items: center; gap: 10px; margin-bottom: 1rem; }
.progress-note { font-size: 12px; color: var(--muted); }

@media(max-width:600px) {
  .header-inner { padding: 0 1rem; }
  .nav-btn { font-size: 12px; padding: 5px 7px; }
  .brand-name { font-size: 20px; }
}
`;

// ─── SMALL HELPERS ────────────────────────────────────────────────────────────
function Alert({ type, msg }) {
  if (!msg) return null;
  const cls = { ok: "alert-ok", error: "alert-err", info: "alert-info" }[type] || "alert-info";
  return <div className={`alert ${cls}`}>{msg}</div>;
}

function useMsg() {
  const [m, setM] = useState(null);
  const show = (type, msg) => { setM({ type, msg }); setTimeout(() => setM(null), 4000); };
  return [m, show];
}

// ─── AUTH PAGE ────────────────────────────────────────────────────────────────
function AuthPage({ onLogin }) {
  const [mode, setMode] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, showMsg] = useMsg();

  async function submit() {
    if (!email || !pw) return showMsg("error", "Email and password required.");
    setLoading(true);
    try {
      if (mode === "login") {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password: pw });
        if (error) throw error;
        onLogin(data.user);
      } else {
        if (!name.trim()) return showMsg("error", "Display name required.");
        const { data, error } = await supabase.auth.signUp({
          email, password: pw,
          options: { data: { display_name: name.trim() } }
        });
        if (error) throw error;
        if (data.user) {
          await supabase.from("profiles").upsert({ id: data.user.id, display_name: name.trim(), email });
          onLogin(data.user);
        } else {
          showMsg("info", "Check your email to confirm your account, then log in.");
        }
      }
    } catch (e) {
      showMsg("error", e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-bg">
      <div className="auth-box">
        <div className="auth-title">FSF Challenge</div>
        <div className="auth-sub">It's like a soccer tournament, but bigger.</div>
        <div className="tabs">
          <button className={`tab ${mode === "login" ? "active" : ""}`} onClick={() => setMode("login")}>Log In</button>
          <button className={`tab ${mode === "register" ? "active" : ""}`} onClick={() => setMode("register")}>Register</button>
        </div>
        <Alert type={msg?.type} msg={msg?.msg} />
        {mode === "register" && (
          <div className="fg">
            <label className="lbl" style={{ color: "#99aabc" }}>Display Name</label>
            <input className="inp dark" placeholder="Your name on the leaderboard" value={name} onChange={e => setName(e.target.value)} />
          </div>
        )}
        <div className="fg">
          <label className="lbl" style={{ color: "#99aabc" }}>Email</label>
          <input className="inp dark" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
        </div>
        <div className="fg">
          <label className="lbl" style={{ color: "#99aabc" }}>Password</label>
          <input className="inp dark" type="password" placeholder="••••••••" value={pw}
            onChange={e => setPw(e.target.value)}
            onKeyDown={e => e.key === "Enter" && submit()} />
        </div>
        <button className="btn btn-gold" style={{ width: "100%", marginTop: 4 }} onClick={submit} disabled={loading}>
          {loading ? "Please wait…" : mode === "login" ? "Log In" : "Create Account"}
        </button>
      </div>
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard({ user, picks }) {
  const [results, setResults] = useState(null);
  useEffect(() => {
    supabase.from("results").select("data").eq("id", 1).single()
      .then(({ data }) => data?.data && setResults(data.data));
  }, []);

  const s1 = calcStage1Score(picks?.stage1 || {}, results?.stage1 || {});
  const s2 = calcStage2Score(picks?.stage2 || {}, results?.stage2 || {});
  const matchesDone = Object.values(picks?.stage1?.matchResults || {}).filter(Boolean).length;
  const firstDone = Object.values(picks?.stage1?.groupFirst || {}).filter(Boolean).length;
  const secondDone = Object.values(picks?.stage1?.groupSecond || {}).filter(Boolean).length;
  const thirdDone = (picks?.stage1?.thirdPlace || []).length;
  const stage2Done = Object.keys(picks?.stage2?.knockout || {}).length;
  const displayName = user.user_metadata?.display_name || user.email.split("@")[0];

  return (
    <div className="page">
      <div style={{ background: "var(--navy)", borderRadius: 12, padding: "1.5rem", marginBottom: "1.25rem" }}>
        <div style={{ fontSize: 11, color: "var(--gold)", fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em", marginBottom: 3 }}>Welcome back</div>
        <div style={{ fontFamily: "var(--ff-display)", fontSize: 30, fontWeight: 700, color: "#fff" }}>{displayName}</div>
        <div style={{ fontSize: 12, color: "rgba(255,255,255,.4)", marginTop: 2 }}>FSF Challenge · 2026 FIFA World Cup</div>
      </div>

      <div className="stat-row">
        <div className="stat"><div className="stat-lbl">Stage 1 pts</div><div className="stat-val">{s1.pts}</div></div>
        <div className="stat"><div className="stat-lbl">Stage 2 pts</div><div className="stat-val">{s2.pts}</div></div>
        <div className="stat"><div className="stat-lbl">Total pts</div><div className="stat-val" style={{ color: "var(--gold)" }}>{s1.pts + s2.pts}</div></div>
        <div className="stat"><div className="stat-lbl">Correct</div><div className="stat-val">{s1.correct + s2.correct}</div></div>
      </div>

      <div className="card" style={{ marginBottom: "1rem" }}>
        <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 10 }}>Submission status</div>
        {[
          ["Match results (72 matches)", matchesDone, 72],
          ["1st place picks (12 groups)", firstDone, 12],
          ["2nd place picks (12 groups)", secondDone, 12],
          ["Best 8 third-place picks", thirdDone, 8],
        ].map(([label, n, max]) => (
          <div key={label} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "5px 0", borderBottom: "1px solid rgba(0,0,0,.05)" }}>
            <span style={{ color: "#445" }}>{label}</span>
            <span style={{ fontWeight: 700, color: n === max ? "var(--success)" : n > 0 ? "#b07000" : "var(--danger)" }}>{n}/{max}</span>
          </div>
        ))}
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "5px 0" }}>
          <span style={{ color: "#445" }}>Stage 2 knockout picks</span>
          <span style={{ fontWeight: 700, color: stage2Done > 0 ? "var(--success)" : "var(--muted)" }}>
            {stage2Done > 0 ? "In progress / submitted" : "Not started"}
          </span>
        </div>
      </div>

      <div className="alert alert-info">
        ⏰ <strong>Stage 1 locks June 11, 2026</strong> before the first match. Save your picks early!
      </div>
    </div>
  );
}

// ─── STAGE 1 PICKS ────────────────────────────────────────────────────────────
function Stage1({ user }) {
  const locked = new Date() >= STAGE1_LOCK;
  const [picks, setPicks] = useState({ matchResults: {}, groupFirst: {}, groupSecond: {}, thirdPlace: [] });
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [msg, showMsg] = useMsg();

  useEffect(() => {
    supabase.from("picks").select("stage1").eq("user_id", user.id).single()
      .then(({ data }) => { if (data?.stage1) setPicks(data.stage1); });
  }, [user.id]);

  function setMatch(id, val) {
    if (locked) return;
    setPicks(p => ({ ...p, matchResults: { ...p.matchResults, [id]: p.matchResults[id] === val ? null : val } }));
    setDirty(true);
  }

  function setFinish(group, pos, team) {
    if (locked) return;
    setPicks(p => {
      const gf = { ...(p.groupFirst || {}) };
      const gs = { ...(p.groupSecond || {}) };
      if (pos === 1) {
        gf[group] = gf[group] === team ? null : team;
        if (gs[group] === team) gs[group] = null;
      } else {
        gs[group] = gs[group] === team ? null : team;
        if (gf[group] === team) gf[group] = null;
      }
      return { ...p, groupFirst: gf, groupSecond: gs };
    });
    setDirty(true);
  }

  function toggleThird(team) {
    if (locked) return;
    setPicks(p => {
      const cur = p.thirdPlace || [];
      const next = cur.includes(team) ? cur.filter(t => t !== team) : cur.length < 8 ? [...cur, team] : cur;
      return { ...p, thirdPlace: next };
    });
    setDirty(true);
  }

  async function save() {
    setSaving(true);
    try {
      const { error } = await supabase.from("picks").upsert(
        { user_id: user.id, stage1: picks },
        { onConflict: "user_id" }
      );
      if (error) throw error;
      showMsg("ok", "Picks saved successfully!");
      setDirty(false);
    } catch (e) {
      showMsg("error", e.message);
    } finally {
      setSaving(false);
    }
  }

  const matchesDone = Object.values(picks.matchResults || {}).filter(Boolean).length;
  const thirdCount = (picks.thirdPlace || []).length;

  return (
    <div className="page">
      <div className="sh">
        <div className="sh-title">Stage 1 — Group Stage</div>
        <div className="sh-sub">Locks June 11 before first kickoff</div>
      </div>
      {locked && <div className="lock-banner">🔒 Stage 1 is locked. Picks are read-only.</div>}
      <Alert type={msg?.type} msg={msg?.msg} />

      {!locked && (
        <div className="save-bar">
          <span className="progress-note">{matchesDone}/72 matches · {Object.values(picks.groupFirst||{}).filter(Boolean).length}/12 groups · {thirdCount}/8 third</span>
          <button className="btn btn-gold btn-sm" onClick={save} disabled={saving || !dirty}>
            {saving ? "Saving…" : dirty ? "Save Picks" : "✓ Saved"}
          </button>
        </div>
      )}

      {Object.entries(GROUPS).map(([g, teams]) => (
        <div className="grp-block" key={g}>
          <div className="grp-hd">
            <div className="grp-lbl">Group {g}</div>
            <div className="grp-teams">{teams.join(" · ")}</div>
          </div>
          <div className="grp-body">
            <div style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".07em", color: "var(--muted)", marginBottom: 6 }}>Match results</div>
            {GROUP_MATCHES.filter(m => m.group === g).map(m => {
              const cur = picks.matchResults?.[m.id];
              return (
                <div className="match-row" key={m.id}>
                  <button className={`pick-btn ${cur === "home" ? "sel" : ""}`} onClick={() => setMatch(m.id, "home")} disabled={locked}>{m.home}</button>
                  <button className={`draw-btn ${cur === "draw" ? "sel" : ""}`} onClick={() => setMatch(m.id, "draw")} disabled={locked}>DRAW</button>
                  <button className={`pick-btn ${cur === "away" ? "sel" : ""}`} onClick={() => setMatch(m.id, "away")} disabled={locked}>{m.away}</button>
                </div>
              );
            })}
            <div className="finish-grid">
              <div>
                <div className="finish-lbl gold-lbl">1st place</div>
                {teams.map(t => (
                  <button key={t} className={`pick-btn ${picks.groupFirst?.[g] === t ? "sel" : ""}`}
                    style={{ display: "block", width: "100%", marginBottom: 4 }}
                    onClick={() => setFinish(g, 1, t)} disabled={locked}>{t}</button>
                ))}
              </div>
              <div>
                <div className="finish-lbl silver-lbl">2nd place</div>
                {teams.map(t => (
                  <button key={t} className={`pick-btn ${picks.groupSecond?.[g] === t ? "sel" : ""}`}
                    style={{ display: "block", width: "100%", marginBottom: 4 }}
                    onClick={() => setFinish(g, 2, t)} disabled={locked}>{t}</button>
                ))}
              </div>
            </div>
          </div>
        </div>
      ))}

      <div className="card" style={{ marginBottom: "1.5rem" }}>
        <div className="sh" style={{ marginBottom: ".75rem" }}>
          <div className="sh-title" style={{ fontSize: 20 }}>Best 8 Third-Place Teams</div>
          <div className="sh-sub">{thirdCount}/8 · 1 pt each</div>
        </div>
        <p style={{ fontSize: 13, color: "var(--muted)", marginBottom: ".75rem" }}>
          Pick exactly 8 teams you think will be the best third-place finishers and advance to the Round of 32.
          {thirdCount >= 8 && !locked && <strong style={{ color: "var(--success)" }}> ✓ 8 selected</strong>}
        </p>
        <div className="third-grid">
          {ALL_TEAMS.map(t => {
            const sel = (picks.thirdPlace || []).includes(t);
            const full = !sel && thirdCount >= 8;
            return (
              <button key={t} className={`third-btn ${sel ? "sel" : ""}`}
                disabled={locked || full} onClick={() => toggleThird(t)}>{t}</button>
            );
          })}
        </div>
      </div>

      {!locked && (
        <div style={{ display: "flex", justifyContent: "center" }}>
          <button className="btn btn-gold" onClick={save} disabled={saving} style={{ minWidth: 220 }}>
            {saving ? "Saving…" : "Save All Stage 1 Picks"}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── STAGE 2 PICKS ────────────────────────────────────────────────────────────
function Stage2({ user }) {
  const locked = new Date() >= STAGE2_LOCK;
  const [picks, setPicks] = useState({ knockout: {} });
  const [bracket, setBracket] = useState(null);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [msg, showMsg] = useMsg();

  useEffect(() => {
    Promise.all([
      supabase.from("picks").select("stage2").eq("user_id", user.id).single(),
      supabase.from("bracket").select("slots").eq("id", 1).single(),
    ]).then(([p, b]) => {
      if (p.data?.stage2) setPicks(p.data.stage2);
      if (b.data?.slots) setBracket(b.data.slots);
    });
  }, [user.id]);

  function pick(round, slotIdx, team) {
    if (locked) return;
    setPicks(p => ({
      ...p,
      knockout: {
        ...p.knockout,
        [round]: {
          ...(p.knockout?.[round] || {}),
          [slotIdx]: p.knockout?.[round]?.[slotIdx] === team ? null : team
        }
      }
    }));
    setDirty(true);
  }

  async function save() {
    setSaving(true);
    try {
      const { error } = await supabase.from("picks").upsert(
        { user_id: user.id, stage2: picks },
        { onConflict: "user_id" }
      );
      if (error) throw error;
      showMsg("ok", "Stage 2 picks saved!");
      setDirty(false);
    } catch (e) {
      showMsg("error", e.message);
    } finally {
      setSaving(false);
    }
  }

  if (!bracket) {
    return (
      <div className="page">
        <div className="sh"><div className="sh-title">Stage 2 — Knockout</div></div>
        <div className="card">
          <div className="alert alert-info" style={{ margin: 0 }}>
            Stage 2 picks will open once all group play finishes and the admin publishes the 32-team bracket. Check back after June 26, 2026.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="sh">
        <div className="sh-title">Stage 2 — Knockout</div>
        <div className="sh-sub">All picks lock before Round of 32</div>
      </div>
      {locked && <div className="lock-banner">🔒 Stage 2 is locked.</div>}
      <Alert type={msg?.type} msg={msg?.msg} />

      {!locked && (
        <div className="save-bar">
          <button className="btn btn-gold btn-sm" onClick={save} disabled={saving || !dirty}>
            {saving ? "Saving…" : dirty ? "Save Picks" : "✓ Saved"}
          </button>
        </div>
      )}

      {KNOCKOUT_ROUNDS.map(round => {
        const slots = bracket[round.id] || [];
        if (!slots.length) return null;
        return (
          <div key={round.id} style={{ marginBottom: "1.75rem" }}>
            <div className="sh" style={{ marginBottom: "1rem" }}>
              <div className="sh-title" style={{ fontSize: 20 }}>{round.label}</div>
              <div className="sh-sub">{round.points} pts per correct</div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px,1fr))", gap: 8 }}>
              {slots.map((slot, i) => (
                <div className="ko-slot" key={i}>
                  <div className="ko-slot-lbl">Match {i + 1}{slot.label ? ` — ${slot.label}` : ""}</div>
                  <div className="ko-teams">
                    {(slot.teams || []).map(t => (
                      <button key={t}
                        className={`pick-btn ${picks.knockout?.[round.id]?.[i] === t ? "sel" : ""}`}
                        style={{ flex: 1 }} disabled={locked}
                        onClick={() => pick(round.id, i, t)}>{t}</button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}

      {!locked && (
        <div style={{ display: "flex", justifyContent: "center" }}>
          <button className="btn btn-gold" onClick={save} disabled={saving} style={{ minWidth: 220 }}>
            {saving ? "Saving…" : "Save All Stage 2 Picks"}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── LEADERBOARD ─────────────────────────────────────────────────────────────
function Leaderboard({ currentUser }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [{ data: profiles }, { data: allPicks }, { data: res }] = await Promise.all([
        supabase.from("profiles").select("*"),
        supabase.from("picks").select("*"),
        supabase.from("results").select("data").eq("id", 1).single(),
      ]);
      const r = res?.data || {};
      const scored = (profiles || []).map(p => {
        const pk = (allPicks || []).find(x => x.user_id === p.id) || {};
        const s1 = calcStage1Score(pk.stage1 || {}, r.stage1 || {});
        const s2 = calcStage2Score(pk.stage2 || {}, r.stage2 || {});
        return { id: p.id, name: p.display_name || p.email, s1: s1.pts, s2: s2.pts, total: s1.pts + s2.pts, correct: s1.correct + s2.correct };
      });
      scored.sort((a, b) => b.total - a.total || b.correct - a.correct);
      scored.forEach((r, i) => { r.rank = i + 1; });
      setRows(scored);
      setLoading(false);
    }
    load();
  }, []);

  return (
    <div className="page">
      <div className="sh"><div className="sh-title">Leaderboard</div><div className="sh-sub">Updates as results are entered</div></div>
      {loading
        ? <div style={{ color: "var(--muted)", padding: "2rem 0" }}>Loading…</div>
        : (
          <div className="card-navy">
            <table className="lb-tbl">
              <thead>
                <tr><th>#</th><th>Player</th><th>Stage 1</th><th>Stage 2</th><th>Total</th><th>Correct</th></tr>
              </thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r.id}>
                    <td><span className={`rank-pill ${r.rank <= 3 ? "rk" + r.rank : "rkn"}`}>{r.rank}</span></td>
                    <td style={{ fontWeight: r.id === currentUser?.id ? 700 : 400 }}>
                      {r.name}{r.id === currentUser?.id && <span style={{ color: "var(--gold)", fontSize: 10, marginLeft: 6 }}>▶ you</span>}
                    </td>
                    <td>{r.s1}</td>
                    <td>{r.s2}</td>
                    <td style={{ fontWeight: 700, color: "var(--gold)" }}>{r.total}</td>
                    <td style={{ color: "rgba(255,255,255,.5)" }}>{r.correct}</td>
                  </tr>
                ))}
                {!rows.length && <tr><td colSpan={6} style={{ textAlign: "center", color: "rgba(255,255,255,.3)", padding: "2rem" }}>No entries yet.</td></tr>}
              </tbody>
            </table>
          </div>
        )
      }
    </div>
  );
}

// ─── USER GUIDE ───────────────────────────────────────────────────────────────
function Guide() {
  return (
    <div className="page">
      <div className="sh"><div className="sh-title">User Guide</div></div>
      <div className="card" style={{ maxWidth: 740 }}>

        <div style={{ marginBottom: "1.75rem" }}>
          <div className="guide-h">Welcome</div>
          <p className="guide-p">FSF Challenge is a prediction competition for the 2026 FIFA World Cup — 48 teams, 104 matches, played across the US, Canada, and Mexico from June 11 to July 19, 2026. Score points by correctly predicting match results, group finishers, and knockout winners across two stages.</p>
        </div>

        <div style={{ marginBottom: "1.75rem" }}>
          <div className="guide-h">Stage 1 — Group Stage</div>
          <p className="guide-p"><strong>Deadline: June 11, 2026, before the first match.</strong> All Stage 1 picks lock at that point with no exceptions.</p>
          <p className="guide-p"><strong>Match Results (72 matches)</strong> — For every group stage match, pick which team wins or pick a draw. <span className="pts">1 pt</span> per correct result.</p>
          <p className="guide-p"><strong>Group Standings</strong> — Pick who finishes 1st and 2nd in each of the 12 groups:</p>
          <table className="sc-tbl" style={{ marginBottom: ".75rem" }}>
            <thead><tr><th>Your Pick</th><th>Actual Result</th><th>Points</th></tr></thead>
            <tbody>
              <tr><td>Picked 1st</td><td>Finished 1st</td><td><span className="pts">3 pts</span></td></tr>
              <tr><td>Picked 2nd</td><td>Finished 2nd</td><td><span className="pts">2 pts</span></td></tr>
              <tr><td>Picked 1st</td><td>Finished 2nd</td><td><span className="pts">1 pt</span></td></tr>
              <tr><td>Picked 2nd</td><td>Finished 1st</td><td><span className="pts">1 pt</span></td></tr>
              <tr><td>Picked 1st or 2nd</td><td>Didn't finish top 2</td><td><span className="pts">0 pts</span></td></tr>
            </tbody>
          </table>
          <p className="guide-p"><strong>Best 8 Third-Place Teams</strong> — Pick exactly 8 teams you think will be the best third-place finishers (and advance to the Round of 32). <span className="pts">1 pt</span> per correct pick.</p>
        </div>

        <div style={{ marginBottom: "1.75rem" }}>
          <div className="guide-h">Stage 2 — Knockout Stage</div>
          <p className="guide-p"><strong>Opens after group play ends (~June 26). Locks before Round of 32 (~July 1).</strong></p>
          <p className="guide-p">Once the 32-team bracket is published, you pick a winner for every match slot in every round. You only need the correct winner — the opponent doesn't matter for scoring.</p>
          <table className="sc-tbl">
            <thead><tr><th>Round</th><th>Correct pick</th></tr></thead>
            <tbody>
              <tr><td>Round of 32</td><td><span className="pts">2 pts</span></td></tr>
              <tr><td>Round of 16</td><td><span className="pts">4 pts</span></td></tr>
              <tr><td>Quarterfinals</td><td><span className="pts">8 pts</span></td></tr>
              <tr><td>Semifinals</td><td><span className="pts">12 pts</span></td></tr>
              <tr><td>Final</td><td><span className="pts">16 pts</span></td></tr>
            </tbody>
          </table>
        </div>

        <div style={{ marginBottom: "1.75rem" }}>
          <div className="guide-h">Leaderboard & Tiebreaker</div>
          <p className="guide-p">The leaderboard shows total points for all participants. Ties are broken by total correct picks across both stages.</p>
        </div>

        <div style={{ marginBottom: "1.75rem" }}>
          <div className="guide-h">Key Dates</div>
          <table className="sc-tbl">
            <thead><tr><th>Event</th><th>Date</th></tr></thead>
            <tbody>
              <tr><td>Tournament begins</td><td>June 11, 2026</td></tr>
              <tr><td>Stage 1 picks lock</td><td>June 11, before first kickoff</td></tr>
              <tr><td>Group stage ends</td><td>~June 26, 2026</td></tr>
              <tr><td>Stage 2 opens</td><td>After bracket is published by admin</td></tr>
              <tr><td>Stage 2 locks</td><td>~July 1, 2026</td></tr>
              <tr><td>World Cup Final</td><td>July 19, 2026</td></tr>
            </tbody>
          </table>
        </div>

        <div>
          <div className="guide-h">Max Possible Points</div>
          <p className="guide-p">
            Stage 1: 72 (match results) + 36 (1st place) + 24 (2nd place) + 8 (3rd place) = <strong>140 pts</strong><br />
            Stage 2: 32 + 32 + 32 + 24 + 16 = <strong>136 pts</strong><br />
            Grand total: <strong>276 points</strong>
          </p>
        </div>

      </div>
    </div>
  );
}

// ─── ADMIN PAGE ───────────────────────────────────────────────────────────────
function Admin() {
  const [authed, setAuthed] = useState(false);
  const [pw, setPw] = useState("");
  const [tab, setTab] = useState("matches");
  const [results, setResults] = useState({ stage1: { matchResults: {}, groupFirst: {}, groupSecond: {}, thirdPlace: [] }, stage2: { knockout: {} } });
  const [bracket, setBracket] = useState({});
  const [users, setUsers] = useState([]);
  const [msg, showMsg] = useMsg();

  useEffect(() => {
    if (!authed) return;
    Promise.all([
      supabase.from("results").select("data").eq("id", 1).single(),
      supabase.from("bracket").select("slots").eq("id", 1).single(),
      supabase.from("profiles").select("*"),
    ]).then(([r, b, u]) => {
      if (r.data?.data) setResults(r.data.data);
      if (b.data?.slots) setBracket(b.data.slots);
      if (u.data) setUsers(u.data);
    });
  }, [authed]);

  function tryAuth() {
    if (pw === ADMIN_PASSWORD) setAuthed(true);
    else showMsg("error", "Incorrect password.");
  }

  // Results setters
  function setMatchResult(id, val) {
    setResults(p => ({ ...p, stage1: { ...p.stage1, matchResults: { ...p.stage1.matchResults, [id]: val } } }));
  }
  function setGF(g, pos, team) {
    setResults(p => {
      const s = { ...p.stage1 };
      if (pos === 1) s.groupFirst = { ...(s.groupFirst || {}), [g]: team };
      else s.groupSecond = { ...(s.groupSecond || {}), [g]: team };
      return { ...p, stage1: s };
    });
  }
  function toggleThirdResult(team) {
    setResults(p => {
      const cur = p.stage1.thirdPlace || [];
      const next = cur.includes(team) ? cur.filter(t => t !== team) : cur.length < 8 ? [...cur, team] : cur;
      return { ...p, stage1: { ...p.stage1, thirdPlace: next } };
    });
  }
  function setKoResult(round, slotIdx, team) {
    setResults(p => ({
      ...p, stage2: {
        ...p.stage2, knockout: {
          ...p.stage2?.knockout,
          [round]: { ...(p.stage2?.knockout?.[round] || {}), [slotIdx]: team }
        }
      }
    }));
  }

  async function saveResults() {
    const { error } = await supabase.from("results").upsert({ id: 1, data: results });
    if (error) showMsg("error", error.message);
    else showMsg("ok", "Results saved.");
  }

  async function saveBracket() {
    const { error } = await supabase.from("bracket").upsert({ id: 1, slots: bracket });
    if (error) showMsg("error", error.message);
    else showMsg("ok", "Bracket published — Stage 2 is now open to users.");
  }

  async function deleteUser(id, name) {
    if (!confirm(`Delete user "${name}" and all their picks?`)) return;
    await supabase.from("picks").delete().eq("user_id", id);
    await supabase.from("profiles").delete().eq("id", id);
    setUsers(prev => prev.filter(u => u.id !== id));
    showMsg("ok", "User deleted.");
  }

  if (!authed) {
    return (
      <div className="page" style={{ maxWidth: 380 }}>
        <div className="sh"><div className="sh-title">Admin</div></div>
        <div className="card">
          <div className="fg">
            <label className="lbl">Admin Password</label>
            <input className="inp" type="password" value={pw} onChange={e => setPw(e.target.value)}
              onKeyDown={e => e.key === "Enter" && tryAuth()} placeholder="Enter password" />
          </div>
          <button className="btn btn-gold" onClick={tryAuth}>Enter</button>
          <div style={{ marginTop: 10 }}><Alert type={msg?.type} msg={msg?.msg} /></div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="sh"><div className="sh-title">Admin Panel</div></div>
      <Alert type={msg?.type} msg={msg?.msg} />
      <div className="tabs">
        {[["matches","Match Results"],["groups","Group Finishes"],["bracket","Bracket & KO Results"],["users","Users"]].map(([v, l]) => (
          <button key={v} className={`tab ${tab === v ? "active" : ""}`} onClick={() => setTab(v)}>{l}</button>
        ))}
      </div>

      {/* ── MATCH RESULTS ── */}
      {tab === "matches" && (
        <div>
          {Object.entries(GROUPS).map(([g, teams]) => (
            <div className="grp-block" key={g}>
              <div className="grp-hd"><div className="grp-lbl">Group {g}</div></div>
              <div className="grp-body">
                {GROUP_MATCHES.filter(m => m.group === g).map(m => {
                  const cur = results.stage1?.matchResults?.[m.id];
                  return (
                    <div className="match-row" key={m.id}>
                      <button className={`pick-btn ${cur === "home" ? "sel" : ""}`} onClick={() => setMatchResult(m.id, "home")}>{m.home}</button>
                      <button className={`draw-btn ${cur === "draw" ? "sel" : ""}`} onClick={() => setMatchResult(m.id, "draw")}>DRAW</button>
                      <button className={`pick-btn ${cur === "away" ? "sel" : ""}`} onClick={() => setMatchResult(m.id, "away")}>{m.away}</button>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
          <div style={{ display: "flex", justifyContent: "center", marginTop: "1rem" }}>
            <button className="btn btn-gold" onClick={saveResults}>Save Match Results</button>
          </div>
        </div>
      )}

      {/* ── GROUP FINISHES ── */}
      {tab === "groups" && (
        <div>
          {Object.entries(GROUPS).map(([g, teams]) => (
            <div className="card" style={{ marginBottom: "1rem" }} key={g}>
              <div style={{ fontFamily: "var(--ff-display)", fontSize: 18, fontWeight: 700, marginBottom: 10 }}>Group {g}</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div>
                  <div className="finish-lbl gold-lbl" style={{ marginBottom: 5 }}>1st place</div>
                  {teams.map(t => (
                    <button key={t} className={`pick-btn ${results.stage1?.groupFirst?.[g] === t ? "sel" : ""}`}
                      style={{ display: "block", width: "100%", marginBottom: 4 }} onClick={() => setGF(g, 1, t)}>{t}</button>
                  ))}
                </div>
                <div>
                  <div className="finish-lbl silver-lbl" style={{ marginBottom: 5 }}>2nd place</div>
                  {teams.map(t => (
                    <button key={t} className={`pick-btn ${results.stage1?.groupSecond?.[g] === t ? "sel" : ""}`}
                      style={{ display: "block", width: "100%", marginBottom: 4 }} onClick={() => setGF(g, 2, t)}>{t}</button>
                  ))}
                </div>
              </div>
            </div>
          ))}
          <div className="card" style={{ marginBottom: "1rem" }}>
            <div style={{ fontFamily: "var(--ff-display)", fontSize: 18, fontWeight: 700, marginBottom: 8 }}>8 Best Third-Place Teams</div>
            <p style={{ fontSize: 12, color: "var(--muted)", marginBottom: 8 }}>{(results.stage1?.thirdPlace || []).length}/8 selected</p>
            <div className="third-grid">
              {ALL_TEAMS.map(t => (
                <button key={t} className={`third-btn ${(results.stage1?.thirdPlace || []).includes(t) ? "sel" : ""}`}
                  onClick={() => toggleThirdResult(t)}>{t}</button>
              ))}
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "center", marginTop: "1rem" }}>
            <button className="btn btn-gold" onClick={saveResults}>Save Group Results</button>
          </div>
        </div>
      )}

      {/* ── BRACKET & KO RESULTS ── */}
      {tab === "bracket" && (
        <div>
          <div className="alert alert-info">Enter the teams for each match slot, then click "Publish Bracket" to open Stage 2 for users. Once the matches are played, enter the winners below.</div>
          {KNOCKOUT_ROUNDS.map(round => {
            const existingSlots = bracket[round.id] || Array.from({ length: round.slots }, () => ({ label: "", teams: ["", ""] }));
            return (
              <div key={round.id} style={{ marginBottom: "1.5rem" }}>
                <div style={{ fontFamily: "var(--ff-display)", fontSize: 20, fontWeight: 700, marginBottom: 8, color: "var(--navy)" }}>
                  {round.label} — <span style={{ color: "var(--gold-dim)" }}>{round.points} pts</span>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(300px,1fr))", gap: 8 }}>
                  {existingSlots.map((slot, i) => (
                    <div className="card" key={i} style={{ padding: "10px 12px" }}>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6 }}>
                        <div>
                          <label className="lbl" style={{ fontSize: 10 }}>Label</label>
                          <input className="inp" style={{ padding: "6px 8px", fontSize: 12 }} value={slot.label || ""} placeholder="e.g. 1A vs 2B"
                            onChange={e => {
                              const upd = [...existingSlots]; upd[i] = { ...upd[i], label: e.target.value };
                              setBracket(p => ({ ...p, [round.id]: upd }));
                            }} />
                        </div>
                        <div>
                          <label className="lbl" style={{ fontSize: 10 }}>Team 1</label>
                          <input className="inp" style={{ padding: "6px 8px", fontSize: 12 }} value={slot.teams?.[0] || ""}
                            onChange={e => {
                              const upd = [...existingSlots]; upd[i] = { ...upd[i], teams: [e.target.value, upd[i].teams?.[1] || ""] };
                              setBracket(p => ({ ...p, [round.id]: upd }));
                            }} />
                        </div>
                        <div>
                          <label className="lbl" style={{ fontSize: 10 }}>Team 2</label>
                          <input className="inp" style={{ padding: "6px 8px", fontSize: 12 }} value={slot.teams?.[1] || ""}
                            onChange={e => {
                              const upd = [...existingSlots]; upd[i] = { ...upd[i], teams: [upd[i].teams?.[0] || "", e.target.value] };
                              setBracket(p => ({ ...p, [round.id]: upd }));
                            }} />
                        </div>
                      </div>
                      {/* Winner entry */}
                      <div style={{ marginTop: 8, paddingTop: 6, borderTop: "1px solid rgba(0,0,0,.06)" }}>
                        <div style={{ fontSize: 10, color: "var(--muted)", marginBottom: 4, textTransform: "uppercase", letterSpacing: ".06em" }}>Result winner</div>
                        <div style={{ display: "flex", gap: 5 }}>
                          {(slot.teams || []).filter(Boolean).map(t => (
                            <button key={t}
                              className={`pick-btn btn-sm ${results.stage2?.knockout?.[round.id]?.[i] === t ? "sel" : ""}`}
                              style={{ flex: 1, fontSize: 11 }}
                              onClick={() => setKoResult(round.id, i, t)}>{t}</button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          <div style={{ display: "flex", gap: 10, justifyContent: "center", marginTop: "1rem", flexWrap: "wrap" }}>
            <button className="btn btn-success" onClick={saveBracket}>Publish Bracket & Open Stage 2</button>
            <button className="btn btn-gold" onClick={saveResults}>Save KO Results</button>
          </div>
        </div>
      )}

      {/* ── USERS ── */}
      {tab === "users" && (
        <div className="card-navy">
          <table className="lb-tbl">
            <thead><tr><th>Name</th><th>Email</th><th></th></tr></thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td>{u.display_name || "—"}</td>
                  <td style={{ color: "rgba(255,255,255,.5)", fontSize: 12 }}>{u.email}</td>
                  <td><button className="btn btn-danger btn-sm" onClick={() => deleteUser(u.id, u.display_name || u.email)}>Delete</button></td>
                </tr>
              ))}
              {!users.length && <tr><td colSpan={3} style={{ textAlign: "center", color: "rgba(255,255,255,.3)", padding: "2rem" }}>No users.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState("home");
  const [picks, setPicks] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user || null);
      setLoading(false);
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      setUser(session?.user || null);
    });
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;
    supabase.from("picks").select("*").eq("user_id", user.id).single()
      .then(({ data }) => setPicks(data || {}));
  }, [user]);

  async function logout() {
    await supabase.auth.signOut();
    setUser(null); setPage("home");
  }

  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#0B1F3A", color: "#EFB824", fontFamily: "sans-serif", fontSize: 18 }}>
      Loading…
    </div>
  );

  if (!user) return <><style>{CSS}</style><AuthPage onLogin={u => { setUser(u); setPage("home"); }} /></>;

  return (
    <>
      <style>{CSS}</style>
      <header className="header">
        <div className="header-inner">
          <div className="brand" onClick={() => setPage("home")}>
            <span className="brand-name">FSF Challenge</span>
            <span className="brand-tag">It's like a soccer tournament, but bigger.</span>
          </div>
          <nav className="nav">
            <button className={`nav-btn ${page === "home" ? "active" : ""}`} onClick={() => setPage("home")}>Home</button>
            <button className={`nav-btn ${page === "stage1" ? "active" : ""}`} onClick={() => setPage("stage1")}>Stage 1</button>
            <button className={`nav-btn ${page === "stage2" ? "active" : ""}`} onClick={() => setPage("stage2")}>Stage 2</button>
            <button className={`nav-btn ${page === "leaderboard" ? "active" : ""}`} onClick={() => setPage("leaderboard")}>Leaderboard</button>
            <button className={`nav-btn ${page === "guide" ? "active" : ""}`} onClick={() => setPage("guide")}>Guide</button>
            <button className={`nav-btn ${page === "admin" ? "active" : ""}`} onClick={() => setPage("admin")}>Admin</button>
            <button className="nav-btn" onClick={logout} style={{ color: "rgba(255,255,255,.3)" }}>Log Out</button>
          </nav>
        </div>
      </header>

      {page === "home"        && <Dashboard user={user} picks={picks} />}
      {page === "stage1"      && <Stage1 user={user} />}
      {page === "stage2"      && <Stage2 user={user} />}
      {page === "leaderboard" && <Leaderboard currentUser={user} />}
      {page === "guide"       && <Guide />}
      {page === "admin"       && <Admin />}
    </>
  );
}
